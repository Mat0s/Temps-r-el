# Dumber - PCB

## Repertoires
- Chargeur : Plans du PCB du chargeur
- Dumber : Plans du PCB du robot Dumber
- Dumber-Cap: Plans de base pour la realisation d'un cap d'extension pour Dumber
- Shield-Pi-Xbee: Carte d'extension pour la raspberry Pi pour connecter un XBEE
- Models: modeles 3D de pieces mecaniques

