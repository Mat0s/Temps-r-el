#!/bin/sh

echo "Generating 20 markers"
example_aruco_create_marker -d=3 --id=1 --ms=100 marker_4X4_1000_1.png
example_aruco_create_marker -d=3 --id=2 --ms=100 marker_4X4_1000_2.png
example_aruco_create_marker -d=3 --id=3 --ms=100 marker_4X4_1000_3.png
example_aruco_create_marker -d=3 --id=4 --ms=100 marker_4X4_1000_4.png
example_aruco_create_marker -d=3 --id=5 --ms=100 marker_4X4_1000_5.png
example_aruco_create_marker -d=3 --id=6 --ms=100 marker_4X4_1000_6.png
example_aruco_create_marker -d=3 --id=7 --ms=100 marker_4X4_1000_7.png
example_aruco_create_marker -d=3 --id=8 --ms=100 marker_4X4_1000_8.png
example_aruco_create_marker -d=3 --id=9 --ms=100 marker_4X4_1000_9.png
example_aruco_create_marker -d=3 --id=10 --ms=100 marker_4X4_1000_10.png
example_aruco_create_marker -d=3 --id=11 --ms=100 marker_4X4_1000_11.png
example_aruco_create_marker -d=3 --id=12 --ms=100 marker_4X4_1000_12.png
example_aruco_create_marker -d=3 --id=13 --ms=100 marker_4X4_1000_13.png
example_aruco_create_marker -d=3 --id=14 --ms=100 marker_4X4_1000_14.png
example_aruco_create_marker -d=3 --id=15 --ms=100 marker_4X4_1000_15.png
example_aruco_create_marker -d=3 --id=16 --ms=100 marker_4X4_1000_16.png
example_aruco_create_marker -d=3 --id=17 --ms=100 marker_4X4_1000_17.png
example_aruco_create_marker -d=3 --id=18 --ms=100 marker_4X4_1000_18.png
example_aruco_create_marker -d=3 --id=19 --ms=100 marker_4X4_1000_19.png
example_aruco_create_marker -d=3 --id=20 --ms=100 marker_4X4_1000_20.png
