#!/bin/bash
pkexec /usr/bin/gdb $*
