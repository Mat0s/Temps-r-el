/*
 * tests.h
 *
 *  Created on: 28 sept. 2023
 *      Author: dimercur
 */

#ifndef TESTS_H_
#define TESTS_H_

void TESTS_Init(void);

#endif /* TESTS_H_ */
